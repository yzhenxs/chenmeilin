<template>
	<div class="tv">
		<h2>tv</h2>		
	</div>
</template>

<script>
	export default {
		
	}
</script>


<style>
	
</style>