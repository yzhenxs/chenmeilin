<template>
	<div class="city">
		<h2>city</h2>		
	</div>
</template>

<script>
	export default {
		
	}
</script>


<style>
	
</style>