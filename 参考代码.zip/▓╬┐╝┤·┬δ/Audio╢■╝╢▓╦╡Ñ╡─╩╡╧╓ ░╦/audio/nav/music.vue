<template>
	<div class="music">
		<h2>music</h2>		
	</div>
</template>

<script>
	export default {
		
	}
</script>


<style>
	
</style>