<template>
	<div class="film">
		<div class="swiper-container">
	        <div class="swiper-wrapper">
	            <div class="swiper-slide">
	            	<div class="movie">
	            		<img src="http://img5.imgtn.bdimg.com/it/u=415293130,2419074865&fm=26&gp=0.jpg" alt="" />
	            		<p>加勒比海盗..</p>
	            		<p>4.5分</p>
	            	</div>
	            </div>
	            <div class="swiper-slide">Slide 2</div>
	            <div class="swiper-slide">Slide 3</div>
	            <div class="swiper-slide">Slide 4</div>
	            <div class="swiper-slide">Slide 5</div>
	            <div class="swiper-slide">Slide 6</div>
	        </div>
	    </div>	
	</div>
</template>
<style scoped>
	@import "../../../assets/lib/swiper/css/swiper.css";
	.swiper-container {
        width: 100%;
        height: 210px;
        margin: 20px auto;
        background: #e5e5e5;
        padding: 10px;
        box-sizing: border-box;
    }
    .swiper-slide {
        text-align: center;
        font-size: 18px;
        background: #fff;
    }
    .movie img{
    	width:100%;
    	height:150px;
    }
    .movie p{
    	margin: -19px 0;
    	font-size: 14px;
    }
</style>
<script>
	import "../../../assets/lib/swiper/js/swiper.js"
	export default {
		mounted(){
			new Swiper('.swiper-container', {
		        pagination: '.swiper-pagination',
		        slidesPerView: 3.2,
		        paginationClickable: true,
		        spaceBetween: 12,
		        freeMode: true
		    });
		}
	}
</script>


