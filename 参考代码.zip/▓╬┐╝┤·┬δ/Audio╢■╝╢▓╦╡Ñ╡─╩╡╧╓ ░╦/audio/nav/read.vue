<template>
	<div class="read">
		<h2>read</h2>		
	</div>
</template>

<script>
	export default {
		
	}
</script>


<style>
	
</style>