<template>
	<div class="audio">
		<Header txt="书影音">
			<img slot="leftImg" src="../../assets/images/ic_actionbar_search_icon.png"/>
			<img slot="rightImg" src="../../assets/images/ic_chat_green.png"/>
		</Header>
		
		<!---nav导航-->
		<div class="nav">
			<div class="nav-list">
				<span :class="{active:nowIndex==0}" @click="nowIndex=0">
					<router-link to="/audio/film">电影</router-link>
				</span>
				<span :class="{active:nowIndex==1}" @click="nowIndex=1">
					<router-link to="/audio/read">读书</router-link>
				</span>
				<span :class="{active:nowIndex==2}" @click="nowIndex=2">
					<router-link to="/audio/tv">电视</router-link>
				</span>
				<span :class="{active:nowIndex==3}" @click="nowIndex=3">
					<router-link to="/audio/city">同城</router-link>
				</span>
				<span :class="{active:nowIndex==4}" @click="nowIndex=4">
					<router-link to="/audio/music">音乐</router-link>
				</span>
			</div>
			<div>
				<router-view></router-view>
			</div>
			
		</div>
		
	</div>
</template>
<style>
	.nav{
		margin-top: 44px;
		height:36px;
		border-bottom: 1px solid #ccc;
		line-height: 36px;
	}
	.nav-list{
		display: flex;
	}
	.nav-list span{
		flex:1;
		text-align: center;
	}
	.nav-list span>a{
		display: block;
		color:#999;
	}
	.active>a{
		font-weight: bold;
		color:green!important;
		border-bottom: 2px solid green;
	}
</style>

<script>
	//引入Header.vue组件
	import Header from "@/components/Header"
	export default {
		components:{
			Header
		},
		data(){
			return {
				nowIndex:0
			}
		}
	}
</script>
