import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router);

//引入五个模块
import Audio from "@/pages/audio/Audio"
import Broadcast from "@/pages/broadcast/Broadcast"
import Group from "@/pages/group/Group"
import Home from "@/pages/home/Home"
import Mine from "@/pages/mine/Mine"

export default new Router({
  routes: [
    {
    	path:"/",
    	component:Home
    },
    {
    	path:"/home",
    	component:Home
    },
    {
    	path:"/audio",
    	component:Audio
    },
    {
    	path:"/broadcast",
    	component:Broadcast
    },
    {
    	path:"/group",
    	component:Group
    },
    {
    	path:"/mine",
    	component:Mine
    }
  ]
})
