<template>
	<div class="banner">
		<div class="swiper-container">
		  <div class="swiper-wrapper">
		    <slot name="swiper-con"></slot>
		  </div>
		  <div :style="{'text-align':paginationPositon}" :class="{'swiper-pagination':paginationShow}"></div>
		</div>
	</div>
</template>


<script>
	//引入js文件
	import "../assets/lib/swiper/js/swiper.js"
	export default {
		props:{
			paginationShow:{
				type:Boolean,
				default:true
			},
			paginationPositon:{
				type:String,
				default:"center"
			},
			autoplay:{
				type:Number,
				default:3000
			},
			loop:{
				type:Boolean,
				default:true
			},
			paginationType:{
				type:String,
				default:"bullets"
			},
			effect:{
				type:String,
				default:"slide"
			}
		},
		mounted(){
			new Swiper(".swiper-container",{
				loop:this.loop,
				pagination:".swiper-pagination",
				autoplay:this.autoplay,
				autoplayDisableOnInteraction:false,//用户操作完轮播图之后，继续轮播
				paginationType:this.paginationType,
				effect:this.effect
			});
		}
	}
</script>


<style>
	/*引入css文件 后面分号一定要带！*/
	@import "../assets/lib/swiper/css/swiper.css";
	.banner{
		height: 150px;
	}
	.banner img{
		height:100%;
		width:100%;
	}
	.swiper-pagination-bullet-active{
		background: #fff;
	}
</style>