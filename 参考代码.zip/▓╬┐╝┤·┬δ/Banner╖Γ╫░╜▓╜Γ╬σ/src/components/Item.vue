<template>
	<div class="item" @click="clickItem">
		<span v-show="!flag"><slot name="normalImg"></slot><br/></span>
		<span v-show="flag"><slot name="activeImg"></slot><br/></span>
		<span :class="{green:flag}">{{txt}}</span>
	</div>
</template>

<script>
	export default {
		props:["txt","mark","sel"],
		//计算属性
		computed:{
			flag:function(){
				if(this.mark === this.sel){
					return true;
				}
				return false;
			}
		},
		methods:{
			clickItem(){
				//抛出自定义事件
				this.$emit("change",this.mark);
				//跳转到对应的视图中
				this.$router.push("/"+this.mark);
			}
		}
		
	}
</script>

<style>
	.green{
		color:green;
	}
	.item{
		flex:1;
		text-align: center;
	}
	.item img{
		width:40px;
	}
	.item span{
		position: relative;
		top:-2px;
		font-size: 12px;
	}
</style>