<template>
	<div class="headerWrap" :class="{headerBg:flag}">
		<span>{{txt}}</span>
		<span class="leftImg"><slot name="leftImg"></slot></span>
		<span class="rightImg"><slot name="rightImg"></slot></span>
		<slot name="search"></slot>
	</div>
</template>


<script>
	export default {
		props:["txt","flag"]
	}
</script>

<style scoped>
	.headerBg{
		background: green!important;
	}
	.headerWrap{
		height:44px;
		line-height: 44px;
		border-bottom: 1px solid #ccc;
		text-align: center;
		position: fixed;
		width:100%;
		left:0;
		top:0;
	}
	.headerWrap .leftImg,.headerWrap .rightImg{
		position: absolute;
	}
	.headerWrap img{
		width:22px;
	}
	.headerWrap .leftImg{
		top:7px;
		right:55px;
	}
	.headerWrap .rightImg{
		top:7px;
		right:15px;
	}
</style>