<template>
	<div class="mine">
		<Header txt="我的">
			<img slot="rightImg" src="../../assets/images/ic_settings.png"/>
		</Header>
	</div>
</template>

<script>
	//引入Header.vue组件
	import Header from "@/components/Header"
	export default {
		components:{
			Header
		}
	}
</script>

<style>
	
</style>