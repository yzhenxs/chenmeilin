<template>
	<div class="broadcast">
		<Header txt="广播">
			<img slot="leftImg" src="../../assets/images/ic_group_chat_share.png"/>
			<img slot="rightImg" src="../../assets/images/ic_chat_green.png"/>
		</Header>
	</div>
</template>

<script>
	//引入Header.vue组件
	import Header from "@/components/Header"
	export default {
		components:{
			Header
		}
	}
</script>

<style>
	
</style>