<template>
	<div class="group">
		<Header txt="小组">
			<!--<img slot="leftImg" :src="src"/>-->
			<img slot="leftImg" src="../../assets/images/ic_actionbar_search_icon.png"/>
			<img slot="rightImg" src="../../assets/images/ic_chat_green.png"/>
		</Header>
	</div>
</template>

<script>
	//引入Header.vue组件
	import Header from "@/components/Header"
	export default {
		components:{
			Header
		},
		/*data(){
			return {
				src:require("../../assets/images/ic_actionbar_search_icon.png")
				//src:"static/ic_actionbar_search_icon.png"
			}
		}*/
	}
</script>

<style>
	
</style>