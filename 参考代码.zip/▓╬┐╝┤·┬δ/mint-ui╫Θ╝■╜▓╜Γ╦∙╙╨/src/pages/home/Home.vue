<template>
	<div class="home">
		<Header flag=true>
			<img slot="rightImg" src="../../assets/images/ic_chat_green.png"/>
			<div class="search" slot="search">
				<input type="text" placeholder="请输入查找内容"/>
				<img src="../../assets/images/ic_search.png" class="searchImg" alt="" />
				<img src="../../assets/images/ic_scan_gray.png" class="scanImg" alt="" />
			</div>
		</Header>
		<!--使用Banner.vue组件-->
		<div class="headerBanner">
			<Banner :paginationShow="true" :autoplay="5000"  paginationPositon="right">
				<div class="swiper-slide" slot="swiper-con">
					<img src="../../assets/images/banner/01.jpg" alt="" />
				</div>
				<div class="swiper-slide" slot="swiper-con">
					<img src="../../assets/images/banner/02.jpg" alt="" />
				</div>
				<div class="swiper-slide" slot="swiper-con">
					<img src="../../assets/images/banner/03.jpg" alt="" />
				</div>
			</Banner>
		</div>
		
		<Cell title="热点" :flag=true></Cell>
		
		<!--使用new.vue-->
		<div class="home-news" id="homeNews">
			<New :id="item.id" :key="item.id" v-for="(item,index) in arr" :desc="item.target.desc" :title="item.title">
				<!--<img slot="smallImg" :src="item.target.cover_url" alt="" />-->
				<img slot="smallImg" v-lazy.homeNews="item.target.cover_url"/>
			</New>
		</div>
	</div>
</template>

<script>
	import Header from "@/components/Header"
	//引入Banner.vue组件
	import Banner from "@/components/Banner"
	
	import Cell from "@/components/Cell"
	
	//引入New.vue
	import New from "@/components/New"
	
	
	export default {
		components:{
			Header,
			Banner,//注册Banner.vue
			Cell,
			New
		},
		data(){
			return {
				arr:[]
			}
		},
		mounted(){
			//访问接口
			//var That = this;
			this.axios.get("/api/homeData").then((res)=>{
				this.arr = res.data.dataInfo.recommend_feeds;
			})
		}
	}
</script>

<style>
	.home-news{
		padding-bottom: 60px;
	}
	h3{
		color:green;
	}
	.headerBanner{
		margin-top: 44px;
	}
	.search{
	    width: 84%;
	    height: 25px;
	    position: relative;
	    left: 5%;
	    top: 22%;
	    border: 1px solid #ccc;
	    border-radius: 4px;
	    background: #fff;
	}
	.search img{
		position: absolute;
		width:16px!important;
	}
	.searchImg{
		left:8px;
		top:4px;
	}
	.scanImg{
		right:8px;
		top:4px;
	}
	.search input{
		font-size: 14px;
		width:80%;
		outline: none;
		border:none;
		position: absolute;
    	left: 10%;
    	top: 14%;
	}
</style>