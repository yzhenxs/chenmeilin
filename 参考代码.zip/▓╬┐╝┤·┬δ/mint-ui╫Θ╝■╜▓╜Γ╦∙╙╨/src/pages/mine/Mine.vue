<template>
	<div class="mine">
		<Header txt="我的">
			<img slot="rightImg" src="../../assets/images/ic_settings.png"/>
		</Header>
		<div class="mine-cell">
			<Cell title="提醒">
				<img slot="leftImg" src="../../assets/images/ic_mine_notification.png" alt="" />
				<img slot="rightImg" src="../../assets/images/ic_arrow_gray_small.png" alt="" />
			</Cell>
		</div>
		
		
		<div>
			<div class="nav">
		      <mt-button :class="{active:active === 'tab-container1'}" size="small" @click.native.prevent="active = 'tab-container1'">tab 1</mt-button>
		      <mt-button :class="{active:active === 'tab-container2'}" size="small" @click.native.prevent="active = 'tab-container2'">tab 2</mt-button>
		      <mt-button :class="{active:active === 'tab-container3'}" size="small" @click.native.prevent="active = 'tab-container3'">tab 3</mt-button>
		    </div>
    
		    <div class="page-tab-container">
		      <mt-tab-container class="page-tabbar-tab-container" v-model="active" swipeable>
		        <mt-tab-container-item id="tab-container1">
		        	<!-- cell组件 -->
		          <!--<mt-cell v-for="n in 10" title="tab-container 1"></mt-cell>-->
		        </mt-tab-container-item>
		        <mt-tab-container-item id="tab-container2">
		        	<!-- cell组件 -->
		          <!--<mt-cell v-for="n in 5" title="tab-container 2"></mt-cell>-->
		        </mt-tab-container-item>
		        <mt-tab-container-item id="tab-container3">
		        	<!-- cell组件 -->
		          <mt-cell :key="item.id" v-for="(item,index) in userInfo" :title="item.username" :value="item.age"></mt-cell>
		        </mt-tab-container-item>
		      </mt-tab-container>
		    </div>
			
		</div>

		
	</div>
</template>

<script>
	//引入Header.vue组件
	import Header from "@/components/Header"
	import Cell from "@/components/Cell"
	export default {
		components:{
			Header,
			Cell
		},
		data(){
			return {
				active:"tab-container1",
				userInfo:[
					{
						id:1,
						username:'张三',
						age:10
					},
					{
						id:2,
						username:'李四',
						age:20
					}
				]
			}
		}
	}
</script>

<style>
	.active{
		background:pink;
	}
	.mine-cell{
		margin-top: 45px;
	}
</style>