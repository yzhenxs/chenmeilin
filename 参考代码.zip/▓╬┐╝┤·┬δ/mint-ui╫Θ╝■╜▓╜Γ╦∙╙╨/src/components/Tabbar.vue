<template>
	<div class="tabbarWrap">
		<Item @change="getVal" txt="首页" mark="home" :sel="selected">
			<img slot="normalImg" src="../assets/images/ic_tab_home_normal.png" alt="" />
			<img slot="activeImg" src="../assets/images/ic_tab_home_active.png" alt="" />
		</Item>
		<Item @change="getVal" txt="书影音" mark="audio" :sel="selected">
			<img slot="normalImg" src="../assets/images/ic_tab_subject_normal.png" alt="" />
			<img slot="activeImg" src="../assets/images/ic_tab_subject_active.png" alt="" />
		</Item>
		<Item @change="getVal" txt="广播" mark="broadcast" :sel="selected">
			<img slot="normalImg" src="../assets/images/ic_tab_status_normal.png" alt="" />
			<img slot="activeImg" src="../assets/images/ic_tab_status_active.png" alt="" />
		</Item>
		<Item @change="getVal" txt="小组" mark="group" :sel="selected">
			<img slot="normalImg" src="../assets/images/ic_tab_group_normal.png" alt="" />
			<img slot="activeImg" src="../assets/images/ic_tab_group_active.png" alt="" />
		</Item>
		<Item @change="getVal" txt="我的" mark="mine" :sel="selected">
			<img slot="normalImg" src="../assets/images/ic_tab_profile_normal.png" alt="" />
			<img slot="activeImg" src="../assets/images/ic_tab_profile_active.png" alt="" />
		</Item>
	</div>
</template>

<script>


	//导入Item.vue组件
//	import Item from "./Item"
	import Item from "@/components/Item"
	export default {
		//注册子组件Item
		components:{
			Item
		},
		data(){
			return {
				selected:"home"
			}
		},
		methods:{
			getVal(mark){
				this.selected = mark;
			}
		}
	}
</script>

<style type="text/css">
	.tabbarWrap{
		position: fixed;
		left:0;
		bottom:0;
		width:100%;
		height:64px;
		display: flex;
		background: #fff;
	}
</style>