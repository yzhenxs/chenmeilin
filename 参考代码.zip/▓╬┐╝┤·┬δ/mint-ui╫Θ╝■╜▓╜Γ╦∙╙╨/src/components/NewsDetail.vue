<template>
	<div class="newsList">
		<!---header-->
		<mt-header :title="title">
		  <a @click="clickBack()" slot="left">
		    <mt-button icon="back">back</mt-button>
		  </a>
		  <mt-button icon="more" slot="right"></mt-button>
		</mt-header>
		
		
		<p>{{id}}</p>
		<h3>{{title}}</h3>
		<p>{{content}}</p>
		<p>
			<img :src="src" alt="" style="max-width: 100%;"/>
		</p>
		<p>
			<router-link to="/home">点我返回首页</router-link>
		</p>
		
		
		<!--<mt-popup
		  v-model="flag"
		  popup-transition="popup-fade">
		  {{title}}
		</mt-popup>-->
		
	</div>
</template>


<script>
	//引入MessageBox
	import {MessageBox} from "mint-ui"

	export default {
		data(){
			return {
				title:"",
				content:"",
				src:"",
				id:"",
				flag:true
			}
		},
		methods:{
			clickBack(){
				MessageBox.confirm('Are you sure?').then(action => {
					this.$router.push("/");
				},action=>{
					
				});
			}
		},
		mounted(){
			//获取id
			var newId = this.$router.currentRoute.params.id;
			//请求接口
//			this.axios.get(url,params:{newId:newId}).then(res=>{
//				this.title = res.data.daljdlaks.title;
//			})
			this.id = newId;
			this.axios.get("/api/homeData").then(res=>{
				var arr = res.data.dataInfo.recommend_feeds;
				arr.forEach((item,index)=>{
					if(item.id === newId){
						this.title = item.title;
						this.content = item.target.desc;
						this.src = item.target.cover_url;
					}
				});
			});
		}
	}
</script>


<style>
	
</style>