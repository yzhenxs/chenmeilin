import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router);

//引入五个模块
import Audio from "@/pages/audio/Audio"
import Broadcast from "@/pages/broadcast/Broadcast"
import Group from "@/pages/group/Group"
import Home from "@/pages/home/Home"
import Mine from "@/pages/mine/Mine"



//引入audio/nav模块
import Film from "@/pages/audio/nav/film"
import Read from "@/pages/audio/nav/read"
import Tv from "@/pages/audio/nav/tv"
import City from "@/pages/audio/nav/city"
import Music from "@/pages/audio/nav/music"



import NewsDetail from "@/components/NewsDetail"

export default new Router({
  routes: [
    {
    	path:"/",
    	component:Home
    },
    {
    	path:"/home",
    	component:Home
    },
    {
    	path:"/audio",
    	component:Audio,
    	children:[
    		{path:"film",component:Film},
    		{path:"read",component:Read},
    		{path:"tv",component:Tv},
    		{path:"city",component:City},
    		{path:"music",component:Music},
    		{path:"",component:Film}
    	]
    },
    {
    	path:"/broadcast",
    	component:Broadcast
    },
    {
    	path:"/group",
    	component:Group
    },
    {
    	path:"/mine",
    	component:Mine
    },
    {
    	path:"/home/:id",
    	component:NewsDetail
    }
  ]
})
