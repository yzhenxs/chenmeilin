<template>
	<div class="home">
		<h3>home</h3>
	</div>
</template>

<script>
	export default {
	}
</script>

<style>
	
</style>