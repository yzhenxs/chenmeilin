<template>
	<div class="home">
		<Header flag=true>
			<img slot="rightImg" src="../../assets/images/ic_chat_green.png"/>
			<div class="search" slot="search">
				<input type="text" placeholder="请输入查找内容"/>
				<img src="../../assets/images/ic_search.png" class="searchImg" alt="" />
				<img src="../../assets/images/ic_scan_gray.png" class="scanImg" alt="" />
			</div>
		</Header>
	</div>
</template>

<script>
	import Header from "@/components/Header"
	export default {
		components:{
			Header
		}
	}
</script>

<style scoped>
	.search{
	    width: 84%;
	    height: 25px;
	    position: relative;
	    left: 5%;
	    top: 22%;
	    border: 1px solid #ccc;
	    border-radius: 4px;
	    background: #fff;
	}
	.search img{
		position: absolute;
		width:16px!important;
	}
	.searchImg{
		left:8px;
		top:4px;
	}
	.scanImg{
		right:8px;
		top:4px;
	}
	.search input{
		font-size: 14px;
		width:80%;
		outline: none;
		border:none;
		position: absolute;
    	left: 10%;
    	top: 14%;
	}
</style>