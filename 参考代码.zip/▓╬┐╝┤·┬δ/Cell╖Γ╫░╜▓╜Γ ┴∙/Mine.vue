<template>
	<div class="mine">
		<Header txt="我的">
			<img slot="rightImg" src="../../assets/images/ic_settings.png"/>
		</Header>
		<div class="mine-cell">
			<Cell title="提醒">
				<img slot="leftImg" src="../../assets/images/ic_mine_notification.png" alt="" />
				<img slot="rightImg" src="../../assets/images/ic_arrow_gray_small.png" alt="" />
			</Cell>
		</div>
	</div>
</template>

<script>
	//引入Header.vue组件
	import Header from "@/components/Header"
	import Cell from "@/components/Cell"
	export default {
		components:{
			Header,
			Cell
		}
	}
</script>

<style>
	.mine-cell{
		margin-top: 45px;
	}
</style>