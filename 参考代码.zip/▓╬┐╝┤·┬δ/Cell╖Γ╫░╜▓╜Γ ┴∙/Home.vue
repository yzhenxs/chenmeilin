<template>
	<div class="home">
		<Header flag=true>
			<img slot="rightImg" src="../../assets/images/ic_chat_green.png"/>
			<div class="search" slot="search">
				<input type="text" placeholder="请输入查找内容"/>
				<img src="../../assets/images/ic_search.png" class="searchImg" alt="" />
				<img src="../../assets/images/ic_scan_gray.png" class="scanImg" alt="" />
			</div>
		</Header>
		<!--使用Banner.vue组件-->
		<div class="headerBanner">
			<Banner :paginationShow="true" :autoplay="5000"  paginationPositon="right">
				<div class="swiper-slide" slot="swiper-con">
					<img src="../../assets/images/banner/01.jpg" alt="" />
				</div>
				<div class="swiper-slide" slot="swiper-con">
					<img src="../../assets/images/banner/02.jpg" alt="" />
				</div>
				<div class="swiper-slide" slot="swiper-con">
					<img src="../../assets/images/banner/03.jpg" alt="" />
				</div>
			</Banner>
		</div>
		
		<Cell title="热点" :flag=true></Cell>
	</div>
</template>

<script>
	import Header from "@/components/Header"
	//引入Banner.vue组件
	import Banner from "@/components/Banner"
	
	import Cell from "@/components/Cell"
	export default {
		components:{
			Header,
			Banner,//注册Banner.vue
			Cell
		}
	}
</script>

<style>
	h3{
		color:green;
	}
	.headerBanner{
		margin-top: 44px;
	}
	.search{
	    width: 84%;
	    height: 25px;
	    position: relative;
	    left: 5%;
	    top: 22%;
	    border: 1px solid #ccc;
	    border-radius: 4px;
	    background: #fff;
	}
	.search img{
		position: absolute;
		width:16px!important;
	}
	.searchImg{
		left:8px;
		top:4px;
	}
	.scanImg{
		right:8px;
		top:4px;
	}
	.search input{
		font-size: 14px;
		width:80%;
		outline: none;
		border:none;
		position: absolute;
    	left: 10%;
    	top: 14%;
	}
</style>