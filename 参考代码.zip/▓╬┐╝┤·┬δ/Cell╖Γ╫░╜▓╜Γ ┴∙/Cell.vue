<template>
	<div class="cellWrap" :class="{hot:flag}">
		<div class="cell-container">
			<span class="leftImg"><slot name="leftImg"></slot></span>
			<span class="title">{{title}}</span>
			<span class="rightImg"><slot name="rightImg"></slot></span>
		</div>
	</div>
</template>

<style lang="less">
	.hot{
		.cell-container{
			&:before{
				content: "";
			    display: inline-block;
			    position: relative;
			    top: 10px;
			    left: -20px;
			    width: 4px;
			    height: 30px;
			    background: orange;
			}
			border-bottom: 0!important;
			.title{
				color:orange;
				font-weight: bold;
				padding-left: 0px!important;
			}
		}
	}
	.cellWrap{
		position: relative;
		padding:10px 20px;
		.cell-container{
			border-bottom: 1px solid #ccc;
			line-height: 34px;
			.leftImg,.rightImg{
				&>img{
					width:25px;
				}
				position: absolute;
				top:14px;
			}
			.title{
				padding-left: 40px;
			}
			.rightImg{
				right:10px;
			}
		}
	}
</style>

<script>
	export default {
		props:{
			title:{
				type:String,
				default:""
			},
			flag:{
				type:Boolean,
				default:false
			}
		}
	}
</script>