<template>
	<div class="news">
		<div class="n-left">
			<h3>{{title}}</h3>
			<p>{{desc}}</p>
		</div>
		<div class="n-right">
			<slot name="smallImg"></slot>
		</div>
	</div>
</template>

<script>
	export default {
		props:{
			title:{
				type:String,
				default:""
			},
			desc:{
				type:String,
				default:""
			}
		}
	}
</script>

<style lang="less">
	.news{
		padding:10px;
		overflow: hidden;
		border-bottom: 1px solid #ccc;
		.n-left{
			float:left;
			width:65%;
		}
		.n-right{
			float:right;
		}
		img{
			width:80px;
			height:80px;
		}
	}
	
</style>