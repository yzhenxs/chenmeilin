import Vuex from "vuex"
import Vue from "vue"

//注册
Vue.use(Vuex);

let store = new Vuex.Store({
	state:{
		totalPrice:0
	},
	getters:{
		getPrice(state){
			return state.totalPrice;
		}
	},
	actions:{ //异步的   context  this.$store
		addOne(context,price){
//			api("asd/action.do").then(function(res){
//				context.commit("addPrice",res.data.price);
//			});
			context.commit("addPrice",price);
		},
		sumOne(context,price){
			context.commit("sumPrice",price);
		}
	},
	mutations:{//都是同步的
		addPrice(state,price){ //this.$store.state
			state.totalPrice += price;
		},
		sumPrice(state,price){
			state.totalPrice -= price;
		}
	}
});

//export default store;
//import store from 路径
export {store};
