<template>
	<div class="broadcast">
		<h3>Broadcast</h3>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style>
	
</style>