<template>
	<div class="home">
		<h3>home  {{price}} </h3>
		<button @click="addOne">add</button>
		<button @click="sumOne">sum</button>
	</div>
</template>

<script>
	export default {
		computed:{
			price:function(){
//				return this.$store.state.totalPrice;
				return this.$store.getters.getPrice;
			}
		},
		methods:{
			addOne(){
				this.$store.dispatch("addOne",5);
			},
			sumOne(){
				this.$store.dispatch("sumOne",5);
			}
		}
	}
</script>

<style>
	
</style>