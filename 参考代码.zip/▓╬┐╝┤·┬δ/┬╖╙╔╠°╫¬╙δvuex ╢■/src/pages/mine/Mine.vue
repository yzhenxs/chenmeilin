<template>
	<div class="mine">
		<h3>mine</h3>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style>
	
</style>