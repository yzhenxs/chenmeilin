<template>
	<div class="audio">
		<h3>Audio {{price}}</h3>
		<button @click="addOne">add</button>
		<button @click="sumOne">sum</button>
	</div>
</template>

<script>
	export default {
		computed:{
			price(){
//				return this.$store.state.totalPrice;
				return this.$store.getters.getPrice;
			}
		},
		methods:{
			addOne(){
//				this.$store.commit("addPrice",15);
				this.$store.dispatch("addOne",15);
			},
			sumOne(){
//				this.$store.commit("sumPrice",15);
				this.$store.dispatch("sumOne",15);
			}
		}
	}
</script>

<style>
	
</style>